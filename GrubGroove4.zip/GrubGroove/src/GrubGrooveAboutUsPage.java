import javax.swing.*;
import java.awt.*;

public class GrubGrooveAboutUsPage extends JFrame {

    public GrubGrooveAboutUsPage() {
        setTitle("About Us - GrubGroove");
        setSize(1920, 1080);
         setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel headerPanel = new JPanel();
        JLabel headerLabel = new JLabel("About Us");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 40));
        headerLabel.setForeground(new Color(51, 102, 204)); // Blue color
        headerPanel.setBackground(Color.magenta); // background
        headerPanel.add(headerLabel);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(05, 162, 151));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        mainPanel.setLayout(new GridLayout(1, 1));

        String description = "<html><body style='width: 900px; font-family: Arial, sans-serif;'>" +
                "<p style='font-size: 22px; line-height: 1.5;'><b>GrubGroove</b> is a unique food delivery service that brings together two great pleasures - delicious meals and your favorite music. We believe that enjoying good food while listening to music enhances the overall dining experience, creating a harmonious blend of taste and sound.</p>" +
                "<p style='font-size: 20px; line-height: 1.5;'>At GrubGroove, we partner with top local restaurants to deliver a wide range of cuisines right to your doorstep. Whether you're craving a hearty burger, a refreshing salad, or a mouthwatering pizza, we have you covered. Simply browse our extensive menu, place your order, and get ready to indulge in a culinary journey like no other.</p>" +
                "<p style='font-size: 20px; line-height: 1.5;'>With GrubGroove, you can create personalized playlists or choose from our curated music collections to accompany your meal. Whether you prefer soothing melodies, upbeat tunes, or your all-time favorite tracks, our music selection will enhance your dining experience and set the perfect mood.</p>" +
                "<p style='font-size: 20px; line-height: 1.5;'>We pride ourselves on our fast and reliable delivery service. Our dedicated team of drivers ensures that your food arrives hot and fresh, while you sit back, relax, and enjoy the melodies that complement your culinary delight.</p>" +
                "<p style='font-size: 20px; line-height: 1.5;'>Join GrubGroove today and elevate your dining experience with a perfect blend of food and music.</p></body></html>";

        JEditorPane descriptionLabel = new JEditorPane("text/html", description);
        descriptionLabel.setEditable(false);
        descriptionLabel.setBackground(new Color(115, 171, 132));

        JScrollPane scrollPane = new JScrollPane(descriptionLabel);

        mainPanel.add(scrollPane);

        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(94, 92, 108)); // Light gray background
        footerPanel.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
        footerPanel.setLayout(new BoxLayout(footerPanel, BoxLayout.Y_AXIS));

        JLabel teamLabel = new JLabel("Our Team");
        teamLabel.setFont(new Font("Arial", Font.BOLD, 20));
        footerPanel.add(teamLabel);
        footerPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        String[] teamMembers = {
                "Cielo Alegam",
                "John Michael Baclayon",
                "Rynze RJ Ferrer Lozano",
                "France Gieb Mier",
                
        };

        for (String member : teamMembers) {
            JLabel memberLabel = new JLabel(member);
            memberLabel.setFont(new Font("Arial", Font.PLAIN, 16));
            footerPanel.add(memberLabel);
        }

        getContentPane().setBackground(new Color(245, 245, 245)); // Light gray background for the entire frame
        setLayout(new BorderLayout());
        add(headerPanel, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);
        add(footerPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GrubGrooveAboutUsPage());
    }
}
