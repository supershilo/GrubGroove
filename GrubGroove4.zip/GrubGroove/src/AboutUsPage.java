import javax.swing.*;
import java.awt.*;

public class AboutUsPage extends JFrame {
    private JPanel contentPanel;

    public AboutUsPage() {
        initializeUI();
    }

    private void initializeUI() {
        setTitle("GrubGroove - About Us");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Get the screen size
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = screenSize.width;
        int screenHeight = screenSize.height;

        // Calculate the scaling factor to fit the screen
        double scalingFactor = Math.min((double) screenWidth / 1920, (double) screenHeight / 1080);

        // Calculate the scaled size based on the scaling factor
        int scaledWidth = (int) (1920 * scalingFactor);
        int scaledHeight = (int) (1080 * scalingFactor);

        // Calculate the position for centering the JFrame
        int posX = (screenWidth - scaledWidth) / 2;
        int posY = (screenHeight - scaledHeight) / 2;

        // Set the JFrame size and position
        setPreferredSize(new Dimension(scaledWidth, scaledHeight));
        setLocation(posX, posY);

        contentPanel = new JPanel(new BorderLayout());

        // Header Panel
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.decode("#558564"));

        JLabel headingLabel = new JLabel("About Us");
        headingLabel.setFont(new Font("Helvetica", Font.BOLD, 48));
        headingLabel.setHorizontalAlignment(SwingConstants.CENTER);
        headingLabel.setForeground(Color.WHITE);
        headerPanel.add(headingLabel, BorderLayout.CENTER);

        contentPanel.add(headerPanel, BorderLayout.NORTH);

        // Main Panel
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(46, 139, 87)); // Sea Green color
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainPanel.setOpaque(true);
        contentPanel.add(mainPanel, BorderLayout.CENTER);

        JTextArea descriptionTextArea = new JTextArea();
        descriptionTextArea.setEditable(false);
        descriptionTextArea.setLineWrap(true);
        descriptionTextArea.setWrapStyleWord(true);
        descriptionTextArea.setFont(new Font("Arial", Font.PLAIN, 24));
        descriptionTextArea.setForeground(Color.BLACK);
        // Create the descriptionLabel and set its properties
        JLabel descriptionLabel = new JLabel("<html>Welcome to GrubGroove!<br><br>"
        + "At GrubGroove, we believe in combining the joy of delicious food with the pleasure of "
        + "listening to your favorite tunes. We are a delivery food service that brings you a wide "
        + "variety of cuisines from your favorite local restaurants, right to your doorstep.<br><br>"
        + "Our unique feature is the integration of music streaming. While you enjoy your meal, "
        + "you can choose from an extensive library of songs and playlists on GrubGroove, provided "
        + "by our partner, Spotify. It's the perfect combination for a delightful dining experience!<br><br>"
        + "We are committed to providing you with a seamless and enjoyable service. Our dedicated "
        + "team of delivery drivers and customer support representatives work round the clock to "
        + "ensure that your orders are delivered on time and that any issues or queries are promptly "
        + "addressed.<br><br>"
        + "Thank you for choosing GrubGroove. We look forward to serving you!</html>");

descriptionLabel.setFont(new Font("Arial", Font.PLAIN, 24));
descriptionLabel.setForeground(Color.BLACK);
descriptionLabel.setVerticalAlignment(SwingConstants.TOP);

// Set the background color for descriptionLabel
descriptionLabel.setOpaque(true);
descriptionLabel.setBackground(Color.WHITE); // Set the desired background color

// Add the descriptionLabel to the mainPanel
mainPanel.add(descriptionLabel, BorderLayout.CENTER);


        // Footer Panel
        JPanel footerPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(255, 0, 255, 128)); // Magenta x Green color with transparency
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        footerPanel.setOpaque(true);

        JTextArea teamMembersTextArea = new JTextArea();
        teamMembersTextArea.setEditable(false);
        teamMembersTextArea.setLineWrap(true);
        teamMembersTextArea.setWrapStyleWord(true);
        teamMembersTextArea.setFont(new Font("Arial", Font.PLAIN, 18));
        teamMembersTextArea.setForeground(Color.BLACK);
        teamMembersTextArea.setText("OUR TEAM:\n\n"
                + "1. John Michael Baclayon\n"
                + "2. France Gieb Mier\n"
                + "3. Rynze RJ Ferrer Lozano\n"
                + "4. Cielo Alegam");

        JScrollPane teamMembersScrollPane = new JScrollPane(teamMembersTextArea);
        teamMembersScrollPane.setBackground(new Color(255, 0, 255, 128)); // Magenta x Green color with transparency
        footerPanel.add(teamMembersScrollPane, BorderLayout.CENTER);

        contentPanel.add(footerPanel, BorderLayout.SOUTH);

        setContentPane(contentPanel);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AboutUsPage::new);
    }
}
