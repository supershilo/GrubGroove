
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


/**
 *
 * @author JohnJohn Baclayon
 */
public class AboutUsSideBar extends javax.swing.JFrame {

    /**
     * Creates new form AboutUsSideBar
     */
    public AboutUsSideBar() {
        
        
        setTitle("GrubGroove");
        setSize(1920, 1080);
        initComponents();
       
        jp1.setVisible(true);
        jptab1.setBackground(Color.magenta);
        
        
        
        
       
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jptab2 = new javax.swing.JPanel();
        jLabel2Services = new javax.swing.JLabel();
        jptab1 = new javax.swing.JPanel();
        jLabel1Home = new javax.swing.JLabel();
        jptab3 = new javax.swing.JPanel();
        jLabel3Contact = new javax.swing.JLabel();
        jptab4 = new javax.swing.JPanel();
        jLabel4About = new javax.swing.JLabel();
        jpLogo = new javax.swing.JPanel();
        Logo = new javax.swing.JLabel();
        jLabelCompanyName = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jPanel2 = new javax.swing.JPanel();
        jp1 = new javax.swing.JPanel();
        jp4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jp3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jp2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1920, 1080));

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));

        jptab2.setBackground(java.awt.Color.blue);
        jptab2.setForeground(new java.awt.Color(204, 204, 204));
        jptab2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jptab2MouseClicked(evt);
            }
        });

        jLabel2Services.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2Services.setForeground(new java.awt.Color(204, 204, 204));
        jLabel2Services.setText("Services");

        javax.swing.GroupLayout jptab2Layout = new javax.swing.GroupLayout(jptab2);
        jptab2.setLayout(jptab2Layout);
        jptab2Layout.setHorizontalGroup(
            jptab2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jptab2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2Services)
                .addGap(108, 108, 108))
        );
        jptab2Layout.setVerticalGroup(
            jptab2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jptab2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel2Services)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jptab1.setBackground(java.awt.Color.blue);
        jptab1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jptab1MouseClicked(evt);
            }
        });

        jLabel1Home.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1Home.setForeground(new java.awt.Color(204, 204, 204));
        jLabel1Home.setText("Home");

        javax.swing.GroupLayout jptab1Layout = new javax.swing.GroupLayout(jptab1);
        jptab1.setLayout(jptab1Layout);
        jptab1Layout.setHorizontalGroup(
            jptab1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jptab1Layout.createSequentialGroup()
                .addGap(92, 92, 92)
                .addComponent(jLabel1Home)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jptab1Layout.setVerticalGroup(
            jptab1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jptab1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1Home, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(14, 14, 14))
        );

        jptab3.setBackground(java.awt.Color.blue);
        jptab3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jptab3MouseClicked(evt);
            }
        });

        jLabel3Contact.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3Contact.setForeground(new java.awt.Color(204, 204, 204));
        jLabel3Contact.setText("Contact");

        javax.swing.GroupLayout jptab3Layout = new javax.swing.GroupLayout(jptab3);
        jptab3.setLayout(jptab3Layout);
        jptab3Layout.setHorizontalGroup(
            jptab3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jptab3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3Contact)
                .addGap(109, 109, 109))
        );
        jptab3Layout.setVerticalGroup(
            jptab3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jptab3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel3Contact)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jptab4.setBackground(java.awt.Color.blue);
        jptab4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jptab4MouseClicked(evt);
            }
        });

        jLabel4About.setBackground(new java.awt.Color(204, 204, 204));
        jLabel4About.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4About.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4About.setText("About");

        javax.swing.GroupLayout jptab4Layout = new javax.swing.GroupLayout(jptab4);
        jptab4.setLayout(jptab4Layout);
        jptab4Layout.setHorizontalGroup(
            jptab4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jptab4Layout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addComponent(jLabel4About)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jptab4Layout.setVerticalGroup(
            jptab4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jptab4Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel4About)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        Logo.setText("Logo");

        javax.swing.GroupLayout jpLogoLayout = new javax.swing.GroupLayout(jpLogo);
        jpLogo.setLayout(jpLogoLayout);
        jpLogoLayout.setHorizontalGroup(
            jpLogoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jpLogoLayout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(60, Short.MAX_VALUE))
        );
        jpLogoLayout.setVerticalGroup(
            jpLogoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jpLogoLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Logo)
                .addGap(40, 40, 40))
        );

        jLabelCompanyName.setFont(new java.awt.Font("Segoe UI", 3, 30)); // NOI18N
        jLabelCompanyName.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCompanyName.setText("GrubGroove");

        jSeparator1.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jptab1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jptab2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jptab3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jptab4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jpLogo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelCompanyName, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jpLogo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelCompanyName)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(jptab1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jptab2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jptab3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jptab4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(593, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(40, 40, 40));

        jp1.setBackground(new java.awt.Color(40, 40, 40));
        jp1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "GrubGroove", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 2, 18))); // NOI18N
        jp1.setPreferredSize(new java.awt.Dimension(742, 768));

        javax.swing.GroupLayout jp1Layout = new javax.swing.GroupLayout(jp1);
        jp1.setLayout(jp1Layout);
        jp1Layout.setHorizontalGroup(
            jp1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 780, Short.MAX_VALUE)
        );
        jp1Layout.setVerticalGroup(
            jp1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 735, Short.MAX_VALUE)
        );

        jp4.setBackground(new java.awt.Color(40, 40, 40));
        jp4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "GrubGroove", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 2, 18))); // NOI18N

        jLabel3.setFont(new java.awt.Font("Segoe UI", 2, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("<html>\n<head>\n    <style>\n        body {\n            font-family: Arial, sans-serif;\n            font-size: 14px;\n            line-height: 1.5;\n            max-width: 795px; /* Added max-width property */\n            margin: 0 auto; /* Center the content */\n            padding: 20px; /* Add some padding */\n        }\n        \n        h1 {\n            font-size: 24px;\n            margin-bottom: 20px;\n        }\n        \n        p {\n            margin-bottom: 15px;\n            text-align: justify; /* Justify the text for a better layout */\n        }\n    </style>\n</head>\n<body>\n    <h1>Welcome to GrubGroove - Your Ultimate Food Delivery Experience!</h1>\n    \n    <p>At GrubGroove, we believe that food delivery should be an enjoyable and immersive experience. We have combined two of life's greatest pleasures - delicious food and favorite music - to create a unique and exciting dining adventure for you.</p>\n    \n    <p>Our mission is to bring convenience and delight to your doorstep. With GrubGroove, you can explore a wide variety of restaurants and cuisines, all from the comfort of your own home. Whether you're craving a cheesy pizza, a sizzling burger, or a healthy salad, we have got you covered.</p>\n    \n    <p>But we don't stop there. We understand that good food is even better when accompanied by your favorite tunes. That's why we have curated an extensive music library, allowing you to create the perfect ambiance for your meal. Sit back, relax, and enjoy your favorite tracks while savoring the flavors of your chosen dishes.</p>\n    \n    <p>We take pride in our seamless ordering process and reliable delivery service. With just a few clicks, you can browse menus, customize your order, and have it delivered right to your doorstep. Our dedicated team of drivers ensures that your food arrives fresh and on time, so you can focus on enjoying your meal.</p>\n    \n    <p>GrubGroove is committed to providing exceptional customer service and satisfaction. We value your feedback and continuously strive to improve your dining experience. Feel free to reach out to our friendly support team with any questions or concerns you may have.</p>\n    \n    <p>Join us at GrubGroove and embark on a culinary journey filled with flavor, convenience, and a touch of musical magic. Let us elevate your food delivery experience to a whole new level.</p>\n    \n    <p>Sincerely,<br>The GrubGroove Team</p>\n</body>\n</html>\n");

        javax.swing.GroupLayout jp4Layout = new javax.swing.GroupLayout(jp4);
        jp4.setLayout(jp4Layout);
        jp4Layout.setHorizontalGroup(
            jp4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp4Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 1168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(439, Short.MAX_VALUE))
        );
        jp4Layout.setVerticalGroup(
            jp4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp4Layout.createSequentialGroup()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 731, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 317, Short.MAX_VALUE))
        );

        jp3.setBackground(new java.awt.Color(40, 40, 40));
        jp3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "GrubGroove", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 2, 18))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Segoe UI", 2, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("<html>\n<head>\n    <style>\n        body {\n            font-family: Arial, sans-serif;\n            font-size: 14px;\n            line-height: 1.5;\n            max-width: 795px; /* Added max-width property */\n            margin: 0 auto; /* Center the content */\n            padding: 20px; /* Add some padding */\n        }\n        \n        h2 {\n            font-size: 20px;\n            margin-bottom: 20px;\n        }\n        \n        p {\n            margin-bottom: 15px;\n        }\n        \n        .contact-info {\n            display: flex;\n            justify-content: space-between;\n            align-items: center;\n            margin-bottom: 15px;\n        }\n    </style>\n</head>\n<body>\n    <h2>Contact Us</h2>\n    \n    <div class=\"contact-info\">\n        <p><strong>Address:</strong> 123 Main Street, Anytown, USA 12345</p>\n        <p><strong>Phone:</strong> (555) 123-4567</p>\n        <p><strong>Email:</strong> info@grubgroove.com</p>\n    </div>\n    \n    <p>We value your feedback and are always here to assist you. If you have any questions, concerns, or suggestions, please feel free to reach out to us using the contact information provided above. Our friendly support team will be happy to assist you.</p>\n    \n    <p>Thank you for choosing GrubGroove for your food delivery needs. We look forward to serving you!</p>\n</body>\n</html>\n");

        javax.swing.GroupLayout jp3Layout = new javax.swing.GroupLayout(jp3);
        jp3.setLayout(jp3Layout);
        jp3Layout.setHorizontalGroup(
            jp3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp3Layout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 851, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(693, Short.MAX_VALUE))
        );
        jp3Layout.setVerticalGroup(
            jp3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp3Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jp2.setBackground(new java.awt.Color(40, 40, 40));
        jp2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "GrubGroove", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 2, 18))); // NOI18N
        jp2.setPreferredSize(new java.awt.Dimension(742, 768));

        javax.swing.GroupLayout jp2Layout = new javax.swing.GroupLayout(jp2);
        jp2.setLayout(jp2Layout);
        jp2Layout.setHorizontalGroup(
            jp2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 780, Short.MAX_VALUE)
        );
        jp2Layout.setVerticalGroup(
            jp2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 736, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jp3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jp2, javax.swing.GroupLayout.DEFAULT_SIZE, 1645, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jp4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jp1, javax.swing.GroupLayout.DEFAULT_SIZE, 1645, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jp3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                    .addComponent(jp2, javax.swing.GroupLayout.DEFAULT_SIZE, 1074, Short.MAX_VALUE)
                    .addContainerGap()))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jp4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jp1, javax.swing.GroupLayout.DEFAULT_SIZE, 1080, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jptab1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jptab1MouseClicked
        // TODO add your handling code here:
        jp1.setVisible(true);
        jp2.setVisible(false);
        jp3.setVisible(false);
        jp4.setVisible(false);
        jptab1.setBackground(Color.magenta);
        jptab2.setBackground(Color.blue);
        jptab3.setBackground(Color.blue);
        jptab4.setBackground(Color.blue);
        
        
        
    }//GEN-LAST:event_jptab1MouseClicked

    private void jptab2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jptab2MouseClicked
        // TODO add your handling code here:
        jp2.setVisible(true);
        jp1.setVisible(false);
        jp3.setVisible(false);
        jp4.setVisible(false);
        jptab2.setBackground(Color.magenta);
        jptab1.setBackground(Color.blue);
        jptab3.setBackground(Color.blue);
        jptab4.setBackground(Color.blue);
        
    }//GEN-LAST:event_jptab2MouseClicked

    private void jptab3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jptab3MouseClicked
        // TODO add your handling code here:
        jp3.setVisible(true);
        jp2.setVisible(false);
        jp1.setVisible(false);
        jp4.setVisible(false);
        jptab3.setBackground(Color.magenta);
        jptab2.setBackground(Color.blue);
        jptab1.setBackground(Color.blue);
        jptab4.setBackground(Color.blue);
    }//GEN-LAST:event_jptab3MouseClicked

    private void jptab4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jptab4MouseClicked
        // TODO add your handling code here:
        jp4.setVisible(true);
        jp2.setVisible(false);
        jp3.setVisible(false);
        jp1.setVisible(false);
        jptab4.setBackground(Color.magenta);
        jptab2.setBackground(Color.blue);
        jptab3.setBackground(Color.blue);
        jptab1.setBackground(Color.blue);
        
    }//GEN-LAST:event_jptab4MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
         JFrame frame = new JFrame("GrubGroove - About US");
         
         
            // Load and scale the logo image
            ImageIcon icon = new ImageIcon("\\src\\Images\\Logo.png");
            Image image = icon.getImage();
            Image scaledImage = image.getScaledInstance(300, 405, Image.SCALE_SMOOTH);
            ImageIcon scaledIcon = new ImageIcon(scaledImage);

            // Create the JLabel with the scaled logo
            JLabel logo = new JLabel(scaledIcon);

            // Create a JPanel to hold the logo label
            JPanel panel = new JPanel();
            panel.setLayout(new FlowLayout(FlowLayout.CENTER)); // Align the logo label to the center
            panel.add(logo);

            // Add the panel to the frame's content pane
            frame.getContentPane().add(panel);
            
            
         
         
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AboutUsSideBar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AboutUsSideBar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AboutUsSideBar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AboutUsSideBar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AboutUsSideBar().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Logo;
    private javax.swing.JLabel jLabel1Home;
    private javax.swing.JLabel jLabel2Services;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel3Contact;
    private javax.swing.JLabel jLabel4About;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabelCompanyName;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JPanel jp1;
    private javax.swing.JPanel jp2;
    private javax.swing.JPanel jp3;
    private javax.swing.JPanel jp4;
    private javax.swing.JPanel jpLogo;
    private javax.swing.JPanel jptab1;
    private javax.swing.JPanel jptab2;
    private javax.swing.JPanel jptab3;
    private javax.swing.JPanel jptab4;
    // End of variables declaration//GEN-END:variables
}
