//for referrence 
//
//import java.awt.*;
//import java.awt.event.*;
//import java.sql.*;
//import javax.swing.*;
//
//public class AboutUsFrame extends JFrame {
//    
//    private JLabel titleLabel, descriptionLabel, addressLabel, phoneLabel, emailLabel;
//    private JButton homeButton, servicesButton, contactButton;
//    
//    public AboutUsFrame() {
//        initComponents();
//        loadData();
//    }
//    
//    
//    private void loadData() {
//    try {
//        Class.forName("com.mysql.jdbc.Driver");
//        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/grubgroove", "root", "");
//        Statement stmt = conn.createStatement();
//        ResultSet rs = stmt.executeQuery("SELECT * FROM about_us");
//        
//        if (rs.next()) {
//            String title = rs.getString("title");
//            String content = rs.getString("content");
//
//            titleLabel.setText(title);
//            contentArea.setText(content);
//        }
//        
//        conn.close();
//    } catch (ClassNotFoundException | SQLException ex) {
//        ex.printStackTrace();
//    }
//    }
//    
//public static void main(String[] args) {
//    SwingUtilities.invokeLater(new Runnable() {
//        public void run() {
//            new AboutUsFrame().setVisible(true);
//        }
//    });
//}
//
//
//
//
//
//
//
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 836, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 593, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

   
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
