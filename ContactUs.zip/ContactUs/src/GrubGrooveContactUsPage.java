import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.*;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class GrubGrooveContactUsPage extends JFrame {

    public GrubGrooveContactUsPage() {
        setTitle("Contact Us - GrubGroove");
        setSize(1920, 1080);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel headerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                int panelWidth = getWidth();
                int panelHeight = getHeight();
                Color color1 = Color.MAGENTA;
                Color color2 = Color.GREEN;

                GradientPaint gradient = new GradientPaint(
                        0, 0, color1,
                        panelWidth, panelHeight, color2
                );
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, panelWidth, panelHeight);
            }
        };

        JLabel headerLabel = new JLabel("Contact Us");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 40));
        headerLabel.setForeground(new Color(51, 102, 204)); // Blue color
        headerPanel.setBackground(Color.magenta); // background
        headerPanel.add(headerLabel);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(159, 164, 169)); // color taupe gray
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        mainPanel.setLayout(new GridLayout(1, 1));

        String description = "<html><body style='width: 900px; font-family: Arial, sans-serif;'>" +
                "<p style='font-size: 22px; line-height: 1.5;'>Thank you for your interest in GrubGroove!<br> We are here to assist you and answer any questions you may have.<br> Please fill out the form below or use the provided contact information to get in touch with us.</p>" +
                "</body></html>";

        JEditorPane descriptionLabel = new JEditorPane("text/html", description);
        descriptionLabel.setEditable(false);
        descriptionLabel.setBackground(new Color(115, 171, 132));

        JScrollPane scrollPane = new JScrollPane(descriptionLabel);

        mainPanel.add(scrollPane);

        JPanel formPanel = new JPanel();
        formPanel.setBackground(new Color(51, 55, 69));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        formPanel.setLayout(new GridLayout(7, 2, 10, 10));

        JLabel nameLabel = new JLabel("Name:");
        formPanel.add(nameLabel);
        JTextField nameField = new JTextField();
        formPanel.add(nameField);
        nameLabel.setForeground(Color.WHITE); // Set label color to White
        nameLabel.setFont(new Font("Arial", Font.BOLD, 18));
    
        
        JLabel emailLabel = new JLabel("Email:");
        formPanel.add(emailLabel);
        JTextField emailField = new JTextField();
        formPanel.add(emailField);
        emailLabel.setForeground(Color.WHITE); // Set label color to White
        emailLabel.setFont(new Font("Arial", Font.BOLD, 18));

        JLabel phoneLabel = new JLabel("Phone:");
        formPanel.add(phoneLabel);
        JTextField phoneField = new JTextField();
        formPanel.add(phoneField);
        
        phoneLabel.setForeground(Color.WHITE); // Set label color to White
        phoneLabel.setFont(new Font("Arial", Font.BOLD, 18));

        JLabel messageLabel = new JLabel("Message:");
        formPanel.add(messageLabel);
        JTextArea messageArea = new JTextArea();
        messageLabel.setForeground(Color.WHITE); // Set label color to White
        messageLabel.setFont(new Font("Arial", Font.BOLD, 18));
        
        JScrollPane messageScrollPane = new JScrollPane(messageArea);
        formPanel.add(messageScrollPane);

        JLabel emptyLabel = new JLabel(""); // Empty label for spacing
        formPanel.add(emptyLabel);

        JButton submitButton = new JButton("Submit");
         formPanel.add(submitButton);
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Display submission message
                JOptionPane.showMessageDialog(GrubGrooveContactUsPage.this,
                        "Your Form Has Been Submitted.", "Form Submitted", JOptionPane.INFORMATION_MESSAGE);

                // Reset form fields
                nameField.setText("");
                emailField.setText("");
                phoneField.setText("");
                messageArea.setText("");
            }
        });

        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(new Color(94, 92, 108)); // dark gray background
        footerPanel.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
        footerPanel.setLayout(new BoxLayout(footerPanel, BoxLayout.Y_AXIS));

        JLabel socialLabel = new JLabel("Connect With Us");
        socialLabel.setFont(new Font("Arial", Font.BOLD, 20));
        footerPanel.add(socialLabel);
        footerPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        JButton twitterButton = new JButton("Twitter");
        footerPanel.add(twitterButton);
         twitterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openWebPage("https://twitter.com"); // Replace with your desired Twitter URL
            }
            
        });
        
        
        JButton facebookButton = new JButton("Facebook");
        footerPanel.add(facebookButton);
        facebookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openWebPage("https://www.facebook.com"); // Replace with your desired Facebook URL
            }
        });
        
        
        JButton instagramButton = new JButton("Instagram");
         footerPanel.add(instagramButton);
         instagramButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openWebPage("https://www.instagram.com"); // Replace with your desired Instagram URL
            }
        });

        getContentPane().setBackground(new Color(245, 245, 245)); // Light gray background for the entire frame
        setLayout(new BorderLayout());
        add(headerPanel, BorderLayout.NORTH);
        add(mainPanel, BorderLayout.CENTER);
        add(formPanel, BorderLayout.WEST);
        add(footerPanel, BorderLayout.SOUTH);
    }

        
        
          // Open a web page in the default browser
    private void openWebPage(String url) {
        try {
            Desktop.getDesktop().browse(new URI(url));
        } catch (IOException | URISyntaxException ex) {
            ex.printStackTrace();
        }
    

    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GrubGrooveContactUsPage());
        GrubGrooveContactUsPage contactUsPage = new GrubGrooveContactUsPage();
         contactUsPage.setVisible(true);
    }

   }
